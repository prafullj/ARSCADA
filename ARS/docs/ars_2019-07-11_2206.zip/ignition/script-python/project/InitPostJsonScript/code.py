content={}
TAGDB={}
taglist={}
def nop():
	pass
	return